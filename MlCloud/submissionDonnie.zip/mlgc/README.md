# Belajar Penerapan Machine Learning dengan Google Cloud

Branch ini digunakan untuk modul Studi Kasus: Membangun Aplikasi Machine Learning Dengan Google Cloud.